burger = document.querySelector('.burger')
container = document.querySelector('.container')
navList = document.querySelector('.nav-list')
rightnav = document.querySelector('.rightnav')



burger.addEventListener('click', () => {
    container.classList.toggle('h-nav');
    rightnav.classList.toggle('v-class');
    navList.classList.toggle('v-class');


})


    function togglehide() {
        let btn1 = document.getElementById('btn1');
        let cont = document.getElementById('cont');  
        if (cont.style.display != 'none') {
            cont.style.display = 'none';
        }
        else {
            cont.style.display = 'block';
        }
}   
function togglehide2() {
    let btn2 = document.getElementById('btn2');
    let cont1 = document.getElementById('cont1');
    if (cont1.style.display != 'none') {
        cont1.style.display = 'none';
    }
    else {
        cont1.style.display = 'block';
    }
}
function togglehide3() {
    let btn3 = document.getElementById('btn3');
    let cont2 = document.getElementById('cont2');
    if (cont2.style.display != 'none') {
        cont2.style.display = 'none';
    }
    else {
        cont2.style.display = 'block';
    }
}

































































































































































